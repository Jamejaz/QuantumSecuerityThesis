import pandas as pd
import re
import gensim
import spacy
import nltk
from nltk.corpus import stopwords
import Stemmer
import tqdm

def preprocess():
    # Download stopwords
    nltk.download('stopwords')

    # Load standard NLTK stopwords
    stop_words = set(stopwords.words('english'))

    # Extend stopwords with additional words
    stop_words.update([
        'make', 'need', 'get', 'thing', 'good', 'well', 'go', 'work', 'way', 'think', 'know', 'say', 'take', 'use', 'find', 'help', 'give', 'put', 'keep', 'see', 'seem', 'try', 'start', 'stop', 'want', 'like', 'ask', 'explain', 'x', 'com', 'time', 'post', 'begin', 'otim', 'blog', 'paper', 'close',
        'people', 'question', 'answer', 'thing', 'example', 'case', 'part', 'point', 'problem', 'solution', 'issue', 'idea', 'method', 'heard', 'user', 'comment', 'timelin', 'guy', 'follow', 'topic', 'https', 'professor', 'lecture',
        'actually', 'probably', 'maybe', 'really', 'already', 'just', 'kind', 'sort', 'basically', 'definitely', 'obviously', 'literally', '_', 'install', 'Paper', "Game"
    ])

    nlp = spacy.load('en_core_web_sm', disable=['parser', 'ner'])

    stemmer = Stemmer.Stemmer('english')

    # Load CSV data
    df = pd.read_csv(r'D:\Thesis\Total Data for Thesis\File.csv')

    # Convert questions to lowercase
    df['question'] = df['question'].astype(str).str.lower()

    # **Step 1: Keep any question that contains any form of "quantum"**
    df = df[df['question'].str.contains(r'quantum[a-z]*', regex=True, na=False)]  # Matches quantum, quantumly, quantumerror, etc.

    # List of relevant keywords
    keywords = {
        "error correction", "surface code", "steane code", "shor code", "quantum parity check", "syndrome measurement",
        "stabilizer", "fault tolerant", "magic state distillation", "state injection model", "zero noise extrapolation",
        "probabilistic error cancellation", "measurement error mitigation", "vqe", "quantum key distribution",
        "BB84", "E91", "NTRU", "Rainbow", "homomorphic encryption", "quantum shielding", "cirq", "randomised benchmarking",
        "depolarizing channel", "decoherence", "toric code", "stim", "color code", "lattice structure", "encryption",
        "no cloning theorem", "quantum teleportation", "bell test", "entanglement purification", "dynamical decoupling",
        "cross talk", "qubit leakage", "quantum gate calibration", "qkd", "noise", "error", "surface", "steane", "shor", "toric"
    }

    keywords = {kw.lower() for kw in keywords}

    df = df[df['question'].apply(lambda x: any(kw in x for kw in keywords))]

    df.drop_duplicates(subset=['question'], keep='first', inplace=True)

    data = df['question'].tolist()

    pbar = tqdm.tqdm(total=len(data))

    new_data = []
    for doc in data:
        new_doc = re.sub(r'<code>.*?</code>', '', doc, flags=re.S)
        new_doc = re.sub(r'<.*?>', '', new_doc)
        new_doc = gensim.utils.simple_preprocess(str(new_doc), deacc=True)
        new_doc = lemmatization(nlp, new_doc)
        new_doc = stemmer.stemWords(new_doc)
        new_doc = [word for word in new_doc if word not in stop_words]
        new_data.append(new_doc)
        pbar.update(1)

    # Remove low-frequency words while keeping keywords safe
    new_data = remove_low_frequency_words(new_data, threshold=10, keywords=keywords, pbar=pbar)
    df['question'] = [",".join(doc) for doc in new_data]

    # Save data to CSV
    df.to_csv(r'D:\Thesis\Total Data for Thesis\NODuplicate_Master_File.csv', index=False)

    pbar.close()

def lemmatization(nlp, doc, allowed_postags=['NOUN', 'ADJ', 'VERB', 'ADV']):
    """Applies lemmatization to words, keeping only specific parts of speech."""
    return [token.lemma_ for token in nlp(" ".join(doc)) if token.pos_ in allowed_postags]

def remove_low_frequency_words(data, threshold=10, keywords=None, pbar=None):
    """Removes words that appear less than `threshold` times in the dataset, but keeps keywords."""
    if keywords is None:
        keywords = set()  

    word_freq = {}
    for doc in data:
        for word in doc:
            word_freq[word] = word_freq.get(word, 0) + 1
        if pbar:
            pbar.update(1)

    low_freq_words = {word for word, count in word_freq.items() if count < threshold and word not in keywords}

    filtered_data = [[word for word in doc if word not in low_freq_words] for doc in data]
    
    if pbar:
        pbar.update(len(data))

    return filtered_data

# Run preprocessing
preprocess()
