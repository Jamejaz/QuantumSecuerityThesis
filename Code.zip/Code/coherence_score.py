import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# data Load
csv_path = "D:/Thesis/File.csv"
df = pd.read_csv(csv_path)

# Sort by number of topics 
df = df.sort_values(by="Topics")

# plot creation
plt.figure(figsize=(10, 5))
plt.plot(df['Topics'], df['Coherence'], marker='o', linestyle='-', color='b', label="Coherence Score")

# X-axis to display only whole numbers
plt.xticks(np.arange(min(df['Topics']), max(df['Topics']) + 1, step=1))

# labels and title
plt.xlabel("Number of Topics (k)")
plt.ylabel("Coherence Score")
plt.title("LDA Coherence Score vs. Number of Topics")
plt.legend()
plt.grid(True)

# Plot display
plt.show()
