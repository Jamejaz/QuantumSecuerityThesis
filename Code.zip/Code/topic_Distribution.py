import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def plot_topic_distribution(topics_path, output_path):
    """
    Plot topic distribution from a topics.csv file.
    
    Args:
    - topics_path (str): Path to the topics.csv file.
    - output_path (str): Path to save the output plot.
    """

    topics = pd.read_csv(topics_path)
    
    # Sort by the number of documents assigned to each topic
    topics = topics.sort_values(by='Question_Count', ascending=False)
    
    sns.set_theme(style="whitegrid")
    
    plt.figure(figsize=(12, 6))
    chart = sns.barplot(
        data=topics,
        x="Topic",  
        y="Question_Count",  
        palette="viridis"
    )
    
    chart.set_xlabel("Topic Index", fontsize=12)
    chart.set_ylabel("Number of questions", fontsize=12)
    chart.set_title("Topic Distribution", fontsize=14)
    chart.set_xticklabels(chart.get_xticklabels(), rotation=45, horizontalalignment='right')

    plt.tight_layout()
    plt.savefig(output_path)
    plt.show()

# Main 
if __name__ == "__main__":
    topics_path = 'D:/Thesis/Total Data for Thesis/LDA/topics/topics.csv'

    output_path = 'D:/Thesis/Total Data for Thesis/LDA/topics/topic_distribution.png'
    
    plot_topic_distribution(topics_path, output_path)
