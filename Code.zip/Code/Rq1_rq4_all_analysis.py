import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import re
import os
from tqdm import tqdm

# ========== CONFIGURATION ==========
INPUT_CSV = r'D:\MS Business Analytics\Thesis and Internship\Programming\Total Data for Thesis\New_Preprocessed_Data\LDA_5_2\17topics\question_topic.csv'
OUTPUT_BASE = r'D:\MS Business Analytics\Thesis and Internship\Programming\Total Data for Thesis\New_Preprocessed_Data\LDA_5_2\17topics\trend\RQ_outputs'
os.makedirs(OUTPUT_BASE, exist_ok=True)

# ========== GLOBAL FIGURE FONT SETTINGS ==========
plt.rcParams.update({
    "font.size": 18,
    "axes.titlesize": 26,
    "axes.labelsize": 23,
    "xtick.labelsize": 18,
    "ytick.labelsize": 18,
    "legend.fontsize": 18,
    "figure.titlesize": 26,
    "axes.titleweight": "bold",
    "axes.labelweight": "bold",
})

# ========== LOAD DATA ==========
df_raw = pd.read_csv(INPUT_CSV)
df_raw.columns = df_raw.columns.str.strip()

print("Available columns:", df_raw.columns.tolist())

if 'Question_body' not in df_raw.columns:
    raise ValueError("Column 'Question_body' not found. Check your CSV column names.")

if 'question_title' in df_raw.columns:
    df_raw['Full_Text'] = (
        df_raw['question_title'].astype(str) + " " +
        df_raw['Question_body'].astype(str)
    ).str.lower().str.strip()
else:
    df_raw['Full_Text'] = (
        df_raw['Question_body'].astype(str)
    ).str.lower().str.strip()

print(f"Total posts loaded: {len(df_raw)}")


# ========== KEYWORD LISTS ==========

# ---- RQ1: Tools and Frameworks ----
quantum_tools = [
    # Frameworks / SDKs
    "qiskit",
    "cirq",
    "pennylane",
    "projectq",
    "pyquil",
    "qdk",

    # Simulators
    "stim",
    "qutip",
    "qulacs",
    "quimb",

    # QKD Network Simulators
    "simulaqron",
    "qunetsim",
    "netsquid",
    "squanch",

    # Post-Quantum Crypto Libraries
    "liboqs",
    "open quantum safe",
    "pqclean",
    "pqcrypto",
    "bouncycastle",
    "bouncy castle",
]


# ---- RQ3: Quantum and Hybrid Algorithms ----
quantum_algorithms = [
    # Quantum Cryptanalysis Algorithms
    "shor's algorithm",
    "shors algorithm",
    "shor algorithm",
    "grover's algorithm",
    "grovers algorithm",
    "simon's algorithm",
    "simons algorithm",
    "deutsch-jozsa",
    "deutsch jozsa",
    "bernstein-vazirani",
    "bernstein vazirani",

    # Core Quantum Algorithms / Subroutines
    "quantum fourier transform",
    "qft",
    "quantum phase estimation",
    "qpe",
    "hhl",
    "amplitude amplification",
    "swap test",
    "quantum counting",
    "quantum walk",
    "quantum annealing",

    # Hybrid Algorithms
    "vqe",
    "variational quantum eigensolver",
    "qaoa",
    "quantum approximate optimization algorithm",
    "adapt-vqe",
]


# ---- RQ3: Classical and Post-Quantum Algorithms ----
classical_algorithms = [
    # Classical Cryptographic Algorithms
    "rsa",
    "aes",
    "advanced encryption standard",
    "data encryption standard",
    "triple des",
    "sha-256",
    "sha-512",
    "sha-3",
    "sha3",
    "hmac",
    "diffie-hellman",
    "ecdsa",
    "elgamal",
    "blowfish",
    "chacha20",

    # Post-Quantum Algorithms
    "kyber",
    "crystals-kyber",
    "dilithium",
    "crystals-dilithium",
    "ntru",
    "frodokem",
    "mceliece",
    "classic mceliece",
    "sphincs",
    "sphincs+",
    "bike kem",
    "hqc",
    "sike",
    "xmss",
]


# ---- Algorithm Type Mapping ----
algorithm_type_map = {
    # Quantum
    "shor's algorithm": "Quantum",
    "shors algorithm": "Quantum",
    "shor algorithm": "Quantum",
    "grover's algorithm": "Quantum",
    "grovers algorithm": "Quantum",
    "simon's algorithm": "Quantum",
    "simons algorithm": "Quantum",
    "deutsch-jozsa": "Quantum",
    "deutsch jozsa": "Quantum",
    "bernstein-vazirani": "Quantum",
    "bernstein vazirani": "Quantum",
    "quantum fourier transform": "Quantum",
    "qft": "Quantum",
    "quantum phase estimation": "Quantum",
    "qpe": "Quantum",
    "hhl": "Quantum",
    "amplitude amplification": "Quantum",
    "swap test": "Quantum",
    "quantum counting": "Quantum",
    "quantum walk": "Quantum",
    "quantum annealing": "Quantum",
    "grover": "Quantum",
    "shor": "Quantum",

    # Hybrid
    "vqe": "Hybrid",
    "variational quantum eigensolver": "Hybrid",
    "qaoa": "Hybrid",
    "quantum approximate optimization algorithm": "Hybrid",
    "adapt-vqe": "Hybrid",

    # Classical
    "rsa": "Classical",
    "aes": "Classical",
    "advanced encryption standard": "Classical",
    "data encryption standard": "Classical",
    "triple des": "Classical",
    "sha-256": "Classical",
    "sha-512": "Classical",
    "sha-3": "Classical",
    "sha3": "Classical",
    "hmac": "Classical",
    "diffie-hellman": "Classical",
    "ecdsa": "Classical",
    "elgamal": "Classical",
    "blowfish": "Classical",
    "chacha20": "Classical",

    # Post-Quantum
    "kyber": "Post-Quantum",
    "crystals-kyber": "Post-Quantum",
    "dilithium": "Post-Quantum",
    "crystals-dilithium": "Post-Quantum",
    "ntru": "Post-Quantum",
    "frodokem": "Post-Quantum",
    "mceliece": "Post-Quantum",
    "classic mceliece": "Post-Quantum",
    "sphincs": "Post-Quantum",
    "sphincs+": "Post-Quantum",
    "bike kem": "Post-Quantum",
    "hqc": "Post-Quantum",
    "sike": "Post-Quantum",
    "xmss": "Post-Quantum",
}
# ---- Canonical Algorithm Mapping for Merging Aliases ----
canonical_algorithm_map = {
    # Quantum
    "shor's algorithm": "Shor's Algorithm",
    "shors algorithm": "Shor's Algorithm",
    "shor algorithm": "Shor's Algorithm",

    "grover's algorithm": "Grover's Algorithm",
    "grovers algorithm": "Grover's Algorithm",

    "simon's algorithm": "Simon's Algorithm",
    "simons algorithm": "Simon's Algorithm",

    "deutsch-jozsa": "Deutsch-Jozsa",
    "deutsch jozsa": "Deutsch-Jozsa",

    "bernstein-vazirani": "Bernstein-Vazirani",
    "bernstein vazirani": "Bernstein-Vazirani",

    "quantum fourier transform": "Quantum Fourier Transform",
    "qft": "Quantum Fourier Transform",

    "quantum phase estimation": "Quantum Phase Estimation",
    "qpe": "Quantum Phase Estimation",

    "hhl": "HHL",

    "amplitude amplification": "Amplitude Amplification",
    "swap test": "SWAP Test",
    "quantum counting": "Quantum Counting",
    "quantum walk": "Quantum Walk",
    "quantum annealing": "Quantum Annealing",

    # Hybrid
    "vqe": "VQE",
    "variational quantum eigensolver": "VQE",

    "qaoa": "QAOA",
    "quantum approximate optimization algorithm": "QAOA",

    "adapt-vqe": "ADAPT-VQE",

    # Classical
    "rsa": "RSA",

    "aes": "AES",
    "advanced encryption standard": "AES",

    "data encryption standard": "DES",
    "triple des": "Triple DES",

    "sha-256": "SHA-256",
    "sha-512": "SHA-512",

    "sha-3": "SHA-3",
    "sha3": "SHA-3",

    "hmac": "HMAC",
    "diffie-hellman": "Diffie-Hellman",
    "ecdsa": "ECDSA",
    "elgamal": "ElGamal",
    "blowfish": "Blowfish",
    "chacha20": "ChaCha20",

    # Post-Quantum
    "kyber": "CRYSTALS-Kyber",
    "crystals-kyber": "CRYSTALS-Kyber",

    "dilithium": "CRYSTALS-Dilithium",
    "crystals-dilithium": "CRYSTALS-Dilithium",

    "ntru": "NTRU",
    "frodokem": "FrodoKEM",

    "mceliece": "Classic McEliece",
    "classic mceliece": "Classic McEliece",

    "sphincs": "SPHINCS+",
    "sphincs+": "SPHINCS+",

    "bike kem": "BIKE",
    "hqc": "HQC",
    "sike": "SIKE",
    "xmss": "XMSS",
}


canonical_type_map = {
    # Quantum
    "Shor's Algorithm": "Quantum",
    "Grover's Algorithm": "Quantum",
    "Simon's Algorithm": "Quantum",
    "Deutsch-Jozsa": "Quantum",
    "Bernstein-Vazirani": "Quantum",
    "Quantum Fourier Transform": "Quantum",
    "Quantum Phase Estimation": "Quantum",
    "HHL": "Quantum",
    "Amplitude Amplification": "Quantum",
    "SWAP Test": "Quantum",
    "Quantum Counting": "Quantum",
    "Quantum Walk": "Quantum",
    "Quantum Annealing": "Quantum",

    # Hybrid
    "VQE": "Hybrid",
    "QAOA": "Hybrid",
    "ADAPT-VQE": "Hybrid",

    # Classical
    "RSA": "Classical",
    "AES": "Classical",
    "DES": "Classical",
    "Triple DES": "Classical",
    "SHA-256": "Classical",
    "SHA-512": "Classical",
    "SHA-3": "Classical",
    "HMAC": "Classical",
    "Diffie-Hellman": "Classical",
    "ECDSA": "Classical",
    "ElGamal": "Classical",
    "Blowfish": "Classical",
    "ChaCha20": "Classical",

    # Post-Quantum
    "CRYSTALS-Kyber": "Post-Quantum",
    "CRYSTALS-Dilithium": "Post-Quantum",
    "NTRU": "Post-Quantum",
    "FrodoKEM": "Post-Quantum",
    "Classic McEliece": "Post-Quantum",
    "SPHINCS+": "Post-Quantum",
    "BIKE": "Post-Quantum",
    "HQC": "Post-Quantum",
    "SIKE": "Post-Quantum",
    "XMSS": "Post-Quantum",
}

# ========== HELPER FUNCTIONS ==========

def save_figure(fig, filename):
    """
    Saves the figure as both PNG and PDF.
    PDF is best for LaTeX papers because it stays sharp.
    """
    png_path = os.path.join(OUTPUT_BASE, filename)
    pdf_path = os.path.join(OUTPUT_BASE, filename.replace(".png", ".pdf"))

    fig.savefig(png_path, dpi=400, bbox_inches='tight')
    fig.savefig(pdf_path, bbox_inches='tight')

    print(f"  Saved: {filename}")
    print(f"  Saved: {os.path.basename(pdf_path)}")


def match_keywords(text, keyword_list):
    """
    Match keywords using word boundaries for short terms,
    simple containment for long phrases (3+ words).
    Special handling for ambiguous terms.
    Returns list of matched keywords.
    """
    text = str(text).lower()
    matched = []

    special_patterns = {
        "shor": r'\bshor\b(?!\s*code)',
    }

    for kw in keyword_list:
        kw_clean = kw.lower().strip()

        if kw_clean in special_patterns:
            pattern = special_patterns[kw_clean]
            if re.search(pattern, text):
                matched.append(kw_clean)

        elif len(kw_clean.split()) >= 3:
            if kw_clean in text:
                matched.append(kw_clean)

        else:
            pattern = r'\b' + re.escape(kw_clean) + r'\b'
            if re.search(pattern, text):
                matched.append(kw_clean)

    return matched


def make_biannual(date_series):
    """Convert date series to biannual period labels."""
    dates = pd.to_datetime(date_series, errors='coerce')
    half = dates.dt.month.apply(lambda m: "H1" if m <= 6 else "H2")
    return dates.dt.year.astype(str) + "-" + half


def get_all_biannual_periods(df, date_col='date', start_year=2017):
    """
    Generate biannual periods from start_year up to the last
    period that actually has data in the dataset.
    """
    dates = pd.to_datetime(df[date_col], errors='coerce').dropna()

    last_date = dates.max()
    last_year = last_date.year
    last_half = "H1" if last_date.month <= 6 else "H2"

    periods = []
    for y in range(start_year, last_year + 1):
        periods.append(f"{y}-H1")
        if y < last_year:
            periods.append(f"{y}-H2")
        elif y == last_year and last_half == "H2":
            periods.append(f"{y}-H2")

    return periods


def plot_bar(data, x_col, y_col, title, xlabel, ylabel,
             filename, color='steelblue', rotation=45):

    fig, ax = plt.subplots(figsize=(16, 9))

    ax.bar(
        data[x_col],
        data[y_col],
        color=color,
        width=0.55,
        edgecolor='black',
        linewidth=0.8
    )

    ax.set_title(title, fontsize=28, fontweight='bold', pad=20)
    ax.set_xlabel(xlabel, fontsize=25, fontweight='bold', labelpad=16)
    ax.set_ylabel(ylabel, fontsize=25, fontweight='bold', labelpad=16)

    ax.set_xticks(range(len(data[x_col])))
    ax.set_xticklabels(
        data[x_col],
        rotation=rotation,
        ha='right',
        fontsize=21,
        fontweight='bold'
    )

    ax.tick_params(axis='y', labelsize=21)
    ax.yaxis.set_major_locator(ticker.MaxNLocator(integer=True))

    for label in ax.get_yticklabels():
        label.set_fontweight('bold')

    ax.grid(axis='y', linestyle='--', alpha=0.35)

    plt.tight_layout()
    save_figure(fig, filename)
    plt.close(fig)


def plot_trend(trend_df, title, filename, biannual_periods):

    fig, ax = plt.subplots(figsize=(20, 10))

    markers = ['o', 's', '^', 'D', 'v', 'P', '*', 'X', 'h', '+']

    for i, col in enumerate(trend_df.columns):
        ax.plot(
            trend_df.index,
            trend_df[col],
            marker=markers[i % len(markers)],
            label=col,
            linewidth=3.2,
            markersize=10
        )

    ax.set_title(title, fontsize=30, fontweight='bold', pad=22)
    ax.set_xlabel('Biannual Period', fontsize=26, fontweight='bold', labelpad=16)
    ax.set_ylabel('Number of Questions', fontsize=26, fontweight='bold', labelpad=16)

    ax.set_xticks(range(len(biannual_periods)))
    ax.set_xticklabels(
        biannual_periods,
        rotation=90,
        fontsize=20,
        fontweight='bold'
    )

    ax.tick_params(axis='y', labelsize=22)

    for label in ax.get_yticklabels():
        label.set_fontweight('bold')

    ax.legend(
        loc='upper left',
        fontsize=20,
        frameon=True,
        fancybox=True,
        framealpha=0.95
    )

    ax.yaxis.set_major_locator(ticker.MaxNLocator(integer=True))
    ax.grid(axis='y', linestyle='--', alpha=0.35)

    plt.tight_layout()
    save_figure(fig, filename)
    plt.close(fig)


def plot_pie_type_distribution(type_counts, filename):

    fig, ax = plt.subplots(figsize=(10, 10))

    wedges, texts, autotexts = ax.pie(
        type_counts['Total_Questions'],
        labels=type_counts['Type'],
        autopct='%1.1f%%',
        startangle=140,
        textprops={
            'fontsize': 22,
            'fontweight': 'bold'
        }
    )

    for autotext in autotexts:
        autotext.set_fontsize(22)
        autotext.set_fontweight('bold')

    ax.set_title(
        'Algorithm Type Distribution',
        fontsize=30,
        fontweight='bold',
        pad=22
    )

    plt.tight_layout()
    save_figure(fig, filename)
    plt.close(fig)


# ========================================
# RQ1: TOOLS AND FRAMEWORKS
# ========================================
print("\n" + "="*50)
print("RQ1: Tools and Frameworks")
print("="*50)

df_q1 = df_raw.copy()

tqdm.pandas(desc="RQ1 Tool Detection")
df_q1['Matched_Tools'] = df_q1['Full_Text'].progress_apply(
    lambda x: match_keywords(x, quantum_tools)
)

df_q1['Mentions_Tool'] = df_q1['Matched_Tools'].apply(
    lambda x: ", ".join(x)
)

df_q1.to_csv(
    os.path.join(OUTPUT_BASE, 'rq1_tools_all_questions.csv'),
    index=False
)

q1_exploded = df_q1[df_q1['Mentions_Tool'] != ''].copy()
q1_exploded = q1_exploded.explode('Matched_Tools')
q1_exploded = q1_exploded[
    q1_exploded['Matched_Tools'].notna() &
    (q1_exploded['Matched_Tools'] != '')
]
q1_exploded.rename(columns={'Matched_Tools': 'Tool'}, inplace=True)

if 'views' in q1_exploded.columns and 'votes' in q1_exploded.columns:
    q1_exploded['views'] = pd.to_numeric(
        q1_exploded['views'], errors='coerce'
    )
    q1_exploded['votes'] = pd.to_numeric(
        q1_exploded['votes'], errors='coerce'
    )

    q1_metrics = q1_exploded.groupby('Tool').agg(
        avg_views=('views', 'mean'),
        avg_votes=('votes', 'mean')
    ).round(2).reset_index()
else:
    q1_metrics = None

q1_summary = q1_exploded['Tool'].value_counts().reset_index()
q1_summary.columns = ['Tool', 'Total_Questions']
q1_summary['Percentage'] = (
    100 * q1_summary['Total_Questions'] / len(df_raw)
).round(2)

if q1_metrics is not None:
    q1_summary = q1_summary.merge(q1_metrics, on='Tool', how='left')

q1_summary.to_csv(
    os.path.join(OUTPUT_BASE, 'rq1_tools_summary.csv'),
    index=False
)

print(q1_summary.to_string(index=False))

if 'date' in df_q1.columns:
    top5_tools = q1_summary.head(5)['Tool'].tolist()

    q1_trend_df = q1_exploded[
        q1_exploded['Tool'].isin(top5_tools)
    ].copy()

    q1_trend_df['BiAnnual'] = make_biannual(q1_trend_df['date'])

    q1_trend_df = q1_trend_df[
        pd.to_datetime(q1_trend_df['date'], errors='coerce').dt.year >= 2017
    ]

    biannual_periods = get_all_biannual_periods(df_raw)

    q1_trend = q1_trend_df.groupby(
        ['BiAnnual', 'Tool']
    ).size().unstack(fill_value=0)

    q1_trend = q1_trend.reindex(biannual_periods, fill_value=0)

    q1_trend.to_csv(
        os.path.join(OUTPUT_BASE, 'rq1_tools_trend.csv')
    )

    plot_trend(
        q1_trend,
        'Top 5 Tools/Frameworks Trend Over Time (2017-2025)',
        'rq1_tools_trend.png',
        biannual_periods
    )

plot_bar(
    q1_summary.head(15),
    'Tool',
    'Total_Questions',
    'Quantum Tools and Frameworks Referenced in Practitioner Discussions',
    'Tool',
    'Number of Questions',
    'rq1_tools_bar.png',
    color='steelblue'
)

print("RQ1 Complete.")


# ========================================
# RQ3: ALGORITHMS
# ========================================
print("\n" + "="*50)
print("RQ3: Algorithms")
print("="*50)

df_q3 = df_raw.copy()
all_algorithms = quantum_algorithms + classical_algorithms

seen = set()
all_algorithms_unique = []

for a in all_algorithms:
    if a.lower() not in seen:
        seen.add(a.lower())
        all_algorithms_unique.append(a)

tqdm.pandas(desc="RQ3 Algorithm Detection")
df_q3['Matched_Algorithms'] = df_q3['Full_Text'].progress_apply(
    lambda x: match_keywords(x, all_algorithms_unique)
)

df_q3['Mentions_Algorithm'] = df_q3['Matched_Algorithms'].apply(
    lambda x: ", ".join(x)
)

df_q3.to_csv(
    os.path.join(OUTPUT_BASE, 'rq3_algorithm_all_questions.csv'),
    index=False
)

q3_exploded = df_q3[df_q3['Mentions_Algorithm'] != ''].copy()
q3_exploded = q3_exploded.explode('Matched_Algorithms')
q3_exploded = q3_exploded[
    q3_exploded['Matched_Algorithms'].notna() &
    (q3_exploded['Matched_Algorithms'] != '')
]
q3_exploded.rename(columns={'Matched_Algorithms': 'Raw_Algorithm'}, inplace=True)

# Keep original post index so the same algorithm is counted only once per post
q3_exploded = q3_exploded.reset_index().rename(columns={'index': 'Post_ID'})

# Merge aliases into one canonical algorithm name
q3_exploded['Algorithm'] = q3_exploded['Raw_Algorithm'].map(
    canonical_algorithm_map
).fillna(q3_exploded['Raw_Algorithm'])

# Count each canonical algorithm only once per post
q3_exploded = q3_exploded.drop_duplicates(
    subset=['Post_ID', 'Algorithm']
)

# Add canonical type mapping
q3_exploded['Type'] = q3_exploded['Algorithm'].map(
    canonical_type_map
).fillna('Unknown')

q3_summary = q3_exploded.groupby(
    ['Algorithm', 'Type']
).size().reset_index(name='Total_Questions')

q3_summary = q3_summary.sort_values('Total_Questions', ascending=False)

q3_summary['Percentage'] = (
    100 * q3_summary['Total_Questions'] / len(df_raw)
).round(2)

if 'views' in df_q3.columns and 'votes' in df_q3.columns:
    q3_exploded['views'] = pd.to_numeric(
        q3_exploded['views'], errors='coerce'
    )
    q3_exploded['votes'] = pd.to_numeric(
        q3_exploded['votes'], errors='coerce'
    )

    q3_metrics = q3_exploded.groupby('Algorithm').agg(
        avg_views=('views', 'mean'),
        avg_votes=('votes', 'mean')
    ).round(2).reset_index()

    q3_summary = q3_summary.merge(q3_metrics, on='Algorithm', how='left')

q3_summary.to_csv(
    os.path.join(OUTPUT_BASE, 'rq3_algorithm_summary.csv'),
    index=False
)

print(q3_summary.to_string(index=False))

plot_bar(
    q3_summary.head(10),
    'Algorithm',
    'Total_Questions',
    'Top 10 Algorithms by Number of Questions',
    'Algorithm',
    'Number of Questions',
    'rq3_algorithms_bar.png',
    color='steelblue'
)

if 'avg_views' in q3_summary.columns:
    plot_bar(
        q3_summary.nlargest(10, 'avg_views'),
        'Algorithm',
        'avg_views',
        'Top 10 Algorithms by Average Views per Question',
        'Algorithm',
        'Average Views',
        'rq3_algorithms_avg_views.png',
        color='coral'
    )

if 'avg_votes' in q3_summary.columns:
    plot_bar(
        q3_summary.nlargest(10, 'avg_votes'),
        'Algorithm',
        'avg_votes',
        'Top 10 Algorithms by Average Votes per Question',
        'Algorithm',
        'Average Votes',
        'rq3_algorithms_avg_votes.png',
        color='mediumseagreen'
    )

if 'date' in df_q3.columns:
    top5_alg = q3_summary.head(5)['Algorithm'].tolist()

    q3_trend_df = q3_exploded[
        q3_exploded['Algorithm'].isin(top5_alg)
    ].copy()

    q3_trend_df['BiAnnual'] = make_biannual(q3_trend_df['date'])

    q3_trend_df = q3_trend_df[
        pd.to_datetime(q3_trend_df['date'], errors='coerce').dt.year >= 2017
    ]

    biannual_periods = get_all_biannual_periods(df_raw)

    q3_trend = q3_trend_df.groupby(
        ['BiAnnual', 'Algorithm']
    ).size().unstack(fill_value=0)

    q3_trend = q3_trend.reindex(biannual_periods, fill_value=0)

    q3_trend.to_csv(
        os.path.join(OUTPUT_BASE, 'rq3_algorithm_trend.csv')
    )

    plot_trend(
        q3_trend,
        'Top 5 Algorithms Trend Over Time (2017-2025)',
        'rq3_algorithms_trend.png',
        biannual_periods
    )

type_counts = q3_summary.groupby('Type')[
    'Total_Questions'
].sum().reset_index()

plot_pie_type_distribution(
    type_counts,
    'rq3_algorithm_type_pie.png'
)

print("RQ3 Complete.")


# ========================================
# FINAL SUMMARY
# ========================================
print("\n" + "="*50)
print("RQ1 AND RQ3 COMPLETE")
print("="*50)
print(f"\nTotal posts analysed:  {len(df_raw)}")
print(f"RQ1 — Tools detected in {df_q1[df_q1['Mentions_Tool'] != ''].shape[0]} posts")
print(f"RQ3 — Algorithms detected in {df_q3[df_q3['Mentions_Algorithm'] != ''].shape[0]} posts")
print(f"\nAll outputs saved to:\n{OUTPUT_BASE}")