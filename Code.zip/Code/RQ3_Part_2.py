import pandas as pd
import os

# Load data
all_questions = pd.read_csv("D:/Thesis/Total Data for Thesis/LDA/topics/trend/q3_algorithm_all_questions.csv")

all_questions['Mentions_Algorithm'] = all_questions['Mentions_Algorithm'].str.lower().str.strip()

# Filter to only final algorithms
algorithms_of_interest = ['shor', 'grover', 'qft', 'rsa', 'qkd', 'vqe', 'qpe', 'ecc', 'qaoa', 'hhl', 'kyber', 'rainbow', 'ntru']
df_filtered = all_questions[all_questions['Mentions_Algorithm'].isin(algorithms_of_interest)].copy()

df_filtered['views'] = pd.to_numeric(df_filtered['views'], errors='coerce')
df_filtered['votes'] = pd.to_numeric(df_filtered['votes'], errors='coerce')
df_filtered['answers'] = pd.to_numeric(df_filtered['answers'], errors='coerce')


summary = df_filtered.groupby('Mentions_Algorithm').agg(
    Total_Questions=('question_title', 'count'),
    Average_Views=('views', 'mean'),
    Average_Votes=('votes', 'mean'),
    Average_Difficulty=('difficulty_score', 'mean')
).reset_index()

# output path
output_path = "D:/Thesis/Total Data for Thesis/LDA/topics/trend/RQ3_outputs"
os.makedirs(output_path, exist_ok=True)

# 8. Save CSV
summary.to_csv(f"{output_path}/RQ3_algorithm_final_metrics_filtered.csv", index=False)

# 9. Done
print("Metrics table saved to:", f"{output_path}/RQ3_algorithm_final_metrics_filtered.csv")
